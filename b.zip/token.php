<?php
$API_KEY = ''; // 545602340:AAH534H5f65AHDw7IdttLv7OzP94kBfF6sw
$Marchand = ''; // api zarinpal.com
$adress = ''; // http://t.me/b300bot
?>

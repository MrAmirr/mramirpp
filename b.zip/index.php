﻿<?php 
ob_start();
include('token.php');
//-------------------------------------------//
define('API_KEY',$API_KEY);
function bot($method,$datas=[]){
$url = "https://api.telegram.org/bot".API_KEY."/".$method;
$ch = curl_init();
curl_setopt($ch,CURLOPT_URL,$url);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
$res = curl_exec($ch);
if(curl_error($ch)){
var_dump(curl_error($ch));
}else{
return json_decode($res);
}
}
//-------------------------------------------//
function sendmessage($chat_id, $text, $mode){bot('sendMessage',['chat_id'=>$chat_id,'text'=>$text,'parse_mode'=>$mode]);}
function pay($chat_id,$Amount,$from_id){
$client = new SoapClient('https://www.zarinpal.com/pg/services/WebGate/wsdl', ['encoding' => 'UTF-8']);
$result = $client->PaymentRequest(
[
'MerchantID' => $Marchand,
'Amount' => $Amount,
'Description' => 'شماره مجازی : '.$from_id,
'Email' => 'Email@Mail.Com',
'Mobile' => '09123456789',
'CallbackURL' => $adress.'/back.php?id='.$chat_id.'&amount='.$Amount,
]);
if ($result->Status == 100) {return "https://www.zarinpal.com/pg/StartPay/".$result->Authority."/ZarinGate";}
}
//-------------------------------------------//
$update = json_decode(file_get_contents('php://input'));
var_dump($update);
$message = $update->message;
$from_id = $message->from->id;
$chat_id = $message->chat->id;
$text = $message->text;
$first_name = $message->from->first_name;
$last_name = $message->from->last_name;
$username = $message->from->username;
$message_id = $update->message->message_id;
$reply = $update->message->reply_to_message;
$re_id = $update->message->reply_to_message->forward_from->id;
//-------------------------------------------//
$left = json_decode(file_get_contents("https://api.telegram.org/bot".API_KEY."/getChatMember?chat_id=@Unumber&user_id=$from_id"))->result->status;
//-------------------------------------------//
$admin = ''; // id admin
$Botid = ''; // id bot bedone @
$channel = ''; // id channel gozaresh ha
$ApiKey = ""; // api shoma az robot @UnumberBot
//-------------------------------------------//
$coun_chin = "🇨🇳 چین 🇨🇳";
$coun_tiland = "🇹🇭 تایلند 🇹🇭";
$coun_rus = "🇷🇺 روسیه 🇷🇺";
$coun_qhazaqh = "🇰🇿 قزاقستان 🇰🇿";
$coun_macaoo = "🇲🇵 ماکائو 🇲🇵";
$coun_phili = "🇵🇭 فیلیپین 🇵🇭";
$coun_america = "🇺🇸 آمریکا 🇺🇸";
$coun_mianmar = "🇲🇲 میانمار 🇲🇲";
$coun_ocrain = "🇺🇦 اوکراین 🇺🇦";
$coun_kamboji = "🇰🇭 کمبوج 🇰🇭";
$coun_engel = "🇬🇧 انگستان ⭐️ 🇬🇧";
$coun_ustra = "🇦🇺 استرالیا ⭐️ 🇦🇺";
$coun_mesr = "🇪🇬 مصر ⭐️ 🇪🇬";
$coun_africa = "🇿🇦 آفریقای جنوبی ⭐️ 🇿🇦";
$coun_malesia = "🇲🇾 مالزی ⭐️ 🇲🇾";
$coun_hongkong = "🇭🇰 هنگ کنگ 🇭🇰";
$coun_andinesi = "🇲🇨 اندونزی 🇲🇨";
$coun_vietnam = "🇻🇳 ویتنام 🇻🇳";
$coun_laus = "🇱🇦 لائوس 🇱🇦";
$coun_kenia = "🇰🇪 کنیا 🇰🇪";
$coun_spain = "🇪🇸 اسپانیا 🇪🇸";
$coun_danmark = "🇩🇰 دانمارک 🇩🇰";

//-------------------------------------------//
$command = file_get_contents("data/$from_id/command.txt");
$count = file_get_contents("data/$chat_id/country.txt");
$upay = file_get_contents("data/$chat_id/upay.txt"); 
$ubuy = file_get_contents("data/$chat_id/ubuy.txt");
$coin = file_get_contents("data/$chat_id/coin.txt");
$number = file_get_contents("data/$chat_id/number.txt");
$ref = file_get_contents("data/$chat_id/ref.txt");
$app = file_get_contents("data/$chat_id/app.txt");
$ShCH = file_get_contents("data/$chat_id/ShCH.txt");
$AllBuy = file_get_contents("data/$chat_id/AllBuy.txt");
$AllBuyT = file_get_contents("data/$chat_id/AllBuyT.txt");
//-------------------------------------------//
$members = file_get_contents("data/members.txt");
$memlist = explode("\n",$members);
$banlist = file_get_contents("data/banlist.txt");
$blist = explode("\n", $banlist);
//-------------------------------------------//
if($coin < 0){file_put_contents("data/$chat_id/coin.txt","0");}
//-------------------------------------------//
if($left == "left"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
📛 برای فعال شدن ربات باید در کانال ربات عضو شوید 📛
☂️ Channel : @Unumber

🤔 چرا باید عضو کانال شویم؟!
🔹 زیرا جهت پشتیبانی و دریافت اطلاعیه ها و آموزش های ربات لازم است حتما عضو کانال باشید ...

⚠️ درصورت عضو نشدن ربات فعال نمی شود ...
✅ پس از عضویت در کانال دستور مورد نظر را دوباره تکرار کنید...
",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[ 
[['text'=>"🔸ورود به کانال🔸",'url'=>"https://telegram.me/joinchat/AAAAAE6uZtuGcF2bmWaeOQ"] ] ] ])
]);
}else{

if (strpos($text,'/start') !== false or $text == "↪️ بازگشت"){

if (!in_array($chat_id,$memlist)){
mkdir("data");
mkdir("data/$from_id");
$members .= $chat_id."\n";
file_put_contents("data/members.txt","$members");
file_put_contents("data/$chat_id/coin.txt","0");
file_put_contents("data/$chat_id/ubuy.txt","0");
file_put_contents("data/$chat_id/ref.txt","0");

$id = str_replace("/start ","",$text);
if ($id != "" && $text != "/start" && $id != $from_id){
SendMessage($id,"یک نفر از طریق لینک شما وارد ربات شد","HTML");
file_put_contents("data/$from_id/refe.txt","$id");
$refs = file_get_contents("data/$id/ref.txt");
$refs = $refs + 1;
file_put_contents("data/$id/ref.txt","$refs");
}
}

file_put_contents("data/$chat_id/command.txt","none");

bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
🌷 سلام ؛ به ربات خرید شماره مجازی خوش آمدید .

☄️ این ربات اتوماتیک است و میتوانید در چند ثانیه شماره دریافت کنید.

🔮 هر سوال و یا مشکلی داشتید میتوانید از طریق قسمت پشتیبانی باما درمیان بگذارید.
🌐 کانال ما : @Unumber
",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"☎️ خرید شماره مجازی"]],
[['text'=>"🌐 اطلاعات حساب"],['text'=>"💰 شارژ حساب"]],
[['text'=>"🗣 پشتیبانی"],['text'=>"♻️ زیرمجموعه گیری"]],
[['text'=>"🔢 پیش شماره ها"],['text'=>"🚸 راهنما"],['text'=>"💳 قیمت ها"]],

],
'resize_keyboard'=>true,
])
]);
}
//-------------------------------------------//
elseif ($text == '🚸 راهنما'){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
🚸 راهنما

🤗شما با استفاده از این ربات هوشمند شماره مجازی کشور ها مختلف را به صورت ارزان خریدار می کنید.
♋️تمام روند خرید و دریافت شماره و ثبت نام در برنامه مورد نظر کاملا اتوماتیک انجام می شود.
🌐طرح شماره مجازی تمام اتومات برای خطوت بیش از 20 کشور در ربات ما مهیا شده است.
📴با کم ترین هزینه ممکن در سریع ترین زمان و امن ترین حالت ممکن شماره مجازی خود را خریداری نمایید.
⚠️در صورت بروز هرگونه مشکل با کلید بر روی دکمه پشتیبانی در منو اصلی با ما ارتباط برقرار نمایید.
🔽از منو زیر جهت راهنمایی استفاده کنید🔽
",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"🤔 شماره مجازی چیست ؟"],['text'=>"⁉️ سوالات متداول"]],
[['text'=>"💰کسب درآمد"],['text'=>"🎥 فیلم آموزش خرید"]],
[['text'=>"↪️ بازگشت"]],
],
'resize_keyboard'=>true,
])
]);
}
elseif ($text == '🤔 شماره مجازی چیست ؟'){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
📱شماره مجازی چیست؟📱

📍هنگام ثبت‌نام در اپلیکیشن‌های پیام ‌رسان و شبکه‌های اجتماعی موبایل، باید از شماره تلفن خود به عنوان شناسه استفاده کنید. اگر از کاربرانی هستید که علاقه‌ای به اشتراک‌گذاری شماره‌ی اصلی خود ندارید یا اینکه نیاز به ثبت‌نام بیش از یک بار در این برنامه‌ها دارید، می‌توانید از شماره‌های مجازی استفاده کنید. همچنین شماره مجازی این امکان را می‌دهد که بدون ثبت سیم کارت و اهراز هویت و بدون صرف وقت و هزینه صاحب شماره از کشور های مختلف شوید.

📍مزایا و کاربرد شماره مجازی چیست؟

➊ تلگرام، واتس اپ، وایبر، اینستاگرام  و... برای ثبت‌نام به شماره تلفن شما نیاز دارند تا کدفعال‌سازی مربوطه را برای تشخیص هویت به تلفن‌تان ارسال کنند که به جای شماره اصلی خود میتوان از شماره مجازی برای فعال کردن حساب خود استفاده کرد.

➋ بسیاری از افراد به دلایل مختلف مانند مدیریت یک اکانت دیگر برای مباحث کاری یا... نیاز به اکانت دوم دارند تا بتوانند در عین ارتباط داشتن با مشتریان، از تلگرام شخصی و خصوصی خود نیز استفاده کنند.
 
➌ بدون ثبت نام در اپراتور و بدون صرف وقت و هزینه و اهراز هویت صاحب شماره مجازی می شوید .

➍ استفاده در تمامی اپلیکیشن های اجتماعی با شماره از کشورهای مختلف!
",
]);
}
elseif ($text == '⁉️ سوالات متداول'){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
🔸شماره خریدم کد نمیده چیکار کنم؟
🔹لطفا فیلم آموزشی نحوه خرید را مشاهده کنید.

🔸فیلم رو هم نگاه کردم بازم کد نداد،چیکار کنم؟
🔹لطفا جهت دریافت کد پس از اطمینان از ارسال کد توسط اپلیکیشن درخواستی به شماره مورد نظر 30 ثانیه صبر کنید و سپس بر روی دکمه دریافت کد کلیک کنید.

🔸شماره رو وارد برنامه (تلگرام) کردم اما میگه اشتباهه،چرا اینجوریه؟
🔹بر روی دکمه بازگشت کلیک کنید سپس مجددا نسبت به دریافت شماره و کد اقدام نمایید.

🔸چجوری موجودی کسب درآمد از زیر مجموعه هام رو به حسابم درخواست واریز بدم؟
🔹بر روی دکمه پشتیبانی در منو اصلی بزنید و مبلغ مورد نظر را به همراه شماره کارت یا شماره شبای بانکی را ارسال نمایید.

🔸شماره بدون ریپورت یعنی چی؟
🔹شماره های مجازی اغلب محدودیت ارسال پیام به اکانت های ایرانی را به مدت 4 روز دارند، بعد از 4 روز این محدودیت از بین خواهد رفت اما نوعی شماره ها در ربات وجود دارد که از همان ابتدا این محدودیت را ندارند و مانند خطوط ایرانی میتوان از همان ابتدا به اکانت های ایرانی پیام داد که اصطلاحا بدون ریپورت نام گذاری شده اند.

🔸چرا قیمت شماره مجازی آمریکا از روسیه بیشتر است؟
🔹خیلی ها این سوال رو پرسیدند باید بگیم که در ربات ما ، شماره ها کاملا اختصاصی هستند و این شماره مجازی آمریکا کاملا اختصاصی است و نه قبلا ثبت شده است و نه به غیر از شما به کسی واگذار خواهد شد. پس شماره مجازی های آمریکا در ربات ما اساسا با شماره مجازی های رایگان مانند text now و talk2 و که یک شماره را به 10 ها نفر اترائه میکنند نیست.

🔸بیش از 3 شماره در روز از ربات خریدم اما بعد از چند ساعت همه شماره ها delete account شدند.
علت چیه؟
🔹علت دیلیت اکانت شدن شماره ها حساس شدن تلگرام نسبت به آی پی شماست.
از آنجایی که تلگرام مخالف با عضو فیک و شماره مجازی در تلگرام است نباید بیش از 3 شماره مجازی بر روی یک آی پی (در یک روز) ثبت نام کنید.
اگر قصد دارید تعداد بالا شماره مجازی خریداری و ثبت نام کنید، باید آی پی خود را پس از ثبت هر 3 شماره تغییر دهید.
برای تغییر آی پی دو راه وجود دارد :
1- استفاده از VPN
2- خاموش و روشن کردن مودم ، یا خاموش و روشن کردن دیتا در تلفن همراه برای چند دقیقه موجب تغییر آی پی شما خواهد شد.
",
]);
}
elseif ($text == '💰کسب درآمد'){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
🔰راهنما کسب درآمد🔰

🐥با دریافت لینک مخصوص زیر مجموعه گیری خود از منو تومان رایگان؛ به ازای هر خرید زیرمجموعه های شما از ربات، اعتبار شما به میزان 20 درصد از مبلغ خریداری شده شارژ می شود.
(برای مثال؛ اگر زیر مجموعه شما 10 هزارتومان خرید کند ، حساب شما 2 هزارتومان شارژ خواهد شد)

🍁برای مثال اگر روزانه 10 نفر از لینک شما عضو ربات شوند، و میانگین هر زیر مجموعه بطور ماهانه 10000 تومان خرید کند.
بعد از یک ماه درآمد شما 600 هزارتومان خواهد رسید!!!

🤗با کمی تبلیغات به راحتی میتوانید میلیونر شوید. 

🙊جهت دریافت لینک مخصوص زیر مجموعه گیری خود به منو اصلی برگشته و دکمه زیرمجموعه گیری را انتخاب نمایید.
",
]);
}
elseif ($text == '🎥 فیلم آموزش خرید'){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
🎥 فیلم آموزش خرید شماره مجازی از ربات :
👉 t.me/Unumber/64
",
]);
}
//-------------------------------------------//
elseif ($text == '🔢 پیش شماره ها'){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
☑️ پیش شماره کشورها :

🇷🇺 روسیه  :  +7
🇨🇳 چین  :   +86
🇮🇩 اندونزی: +62
🇵🇭 فیلیپین :  +63
🇹🇭   تایلند :   +66
🇰🇿  قزاقستان:   +7
🇻🇳 ویتنام :  +84
🇭🇰 هنگ کنگ  :   +852
🇰🇭  کامبوج :  +855
🇲🇵  ماکائو  :  +853
🇺🇦 اوکراین :   +380
🇲🇲 میانمار :  +95
🇺🇸 آمریکا  :  +1
🇲🇾 مالزی  : +60
🇪🇬 مصر  : +20
🇦🇺 استرالیا:  +61
🇬🇧 انگلستان:  +44
🇿🇦 آفریقای جنوبی :  +27
🇰🇪 کنیا :  +254
🇱🇦 لائوس :  +856
",
'parse_mode'=>'HTML',
]);
}
//-------------------------------------------//
elseif ($text == '💳 قیمت ها'){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
🌕 لیست قیمت شماره ها :
⭐️ : شماره هایی که هنگام نصب ریپورت نیستند .

🇷🇺روسیه : 1,000 تومان
🇨🇳چین : 2,000 تومان
🇬🇧 انگستان ⭐️ : 3,000 تومان
🇱🇦 لائوس : 3,000 تومان
🇰🇪 کنیا : 3,000 تومان
🇰🇿 قزاقستان : 3,000 تومان
🇲🇵ماکائو : 3,000 تومان
🇰🇭کمبوج : 3,000 تومان
🇺🇦 اوکراین : 3,000 تومان
🇭🇰هنگ کنگ : 3,000 تومان
🇿🇦 آفریقای جنوبی ⭐️ : 4,000 تومان
🇪🇬مصر ⭐️ : 4,000 تومان
🇻🇳ویتنام : 4,000 تومان
🇹🇭تایلند : 4,000 تومان
🇺🇸آمریکا : 4,000 تومان
🇲🇨اندونزی : 5,000 تومان
🇵🇭فیلیپین : 5,000 تومان
🇨🇰استراليا  : 6,000 تومان
🇲🇾مالزی ⭐️ : 7,000 تومان
🇲🇲میانمار : 7,000 تومان
",
'parse_mode'=>'HTML',
]);
}
//-------------------------------------------//
elseif ($text == '♻️ زیرمجموعه گیری'){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
📛 با زیرمجموعه گیری 10% هر خرید زیرمجموعه تان به شما تعلق میگیرد.

💠 لینک اختصاصی شما :
Http://T.me/$Botid?start=$from_id
",
'parse_mode'=>'HTML',
]);
}
//-------------------------------------------//
elseif ($text == '🌐 اطلاعات حساب'){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
👤 نام : $first_name$last_name
◽️ یوزرنیم : @$username
🏷 آیدی : $chat_id
➖➖➖➖➖➖➖➖➖➖➖➖
💰 موجودی : $coin تومان
☎️ تعداد خرید ها : $ubuy تا
👥 زیر مجموعه ها : $ref نفر
",
'parse_mode'=>'HTML',
]);
}
//-------------------------------------------//
elseif ($text == '🗣 پشتیبانی'){
file_put_contents("data/$chat_id/command.txt","support"); 
    bot('sendMessage',[
    'chat_id'=>$chat_id,
    'text'=>"📩 پیام خود را ارسال کنید :",
    'parse_mode'=>'HTML',
    'reply_markup'=>json_encode([
    'keyboard'=>[
        [['text'=>"↪️ بازگشت"]],
    ],'resize_keyboard'=>true,
    ])
    ]);
}
elseif ($command == 'support'){
if (!in_array($chat_id, $blist)){
    bot("forwardMessage",['chat_id' =>$admin,'from_chat_id'=>$chat_id,'message_id' => $message_id]);
    sendmessage($chat_id,"✅ پیام شما ارسال شد.","HTML");
} else {
file_put_contents("data/$chat_id/command.txt","none");
sendmessage($chat_id,"⛔️ شما بدلیل تخلف مسدود شده اید","HTML");
}
}
elseif ($chat_id == $admin and $reply){
    if($text == "/ban"){
        if(!in_array($re_id, $blist)){
        file_put_contents("data/banlist.txt","\n". $re_id,FILE_APPEND);
        sendmessage($chat_id,"❌ کاربر مسدود شد .","HTML");
        }  
    }
    elseif($text == "/unban"){
        if(in_array($re_id, $blist)){
        $bli = str_replace("\n" . $re_id,'',$banlist);
        file_put_contents("data/banlist.txt", $bli);
        sendmessage($chat_id,"✅ کاربر آزاد شد .","HTML");
        }
    }else{
        sendmessage($re_id,$text,"HTML");
        sendmessage($chat_id,"✅ پیام شما ارسال شد.","HTML");
    }
}
//-------------------------------------------//
elseif ($text == '💰 شارژ حساب'){
sendMessage($chat_id,'💵 درحال ساخت لینک پرداخت...');
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
⚠️ برو روی مبلغ دلخواه کلیک کنید سپس به صفحه پرداخت می روید و پس از پرداخت وجه اتوماتیک حساب شما شارژ میشود.
",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"💰 2,000 تومان",'url'=>pay($chat_id,'2000',$from_id)],['text'=>"💰 3,000 تومان",'url'=>pay($chat_id,'3000',$from_id)]],
[['text'=>"💰 4,000 تومان",'url'=>pay($chat_id,'4000',$from_id)],['text'=>"💰 5,000 تومان",'url'=>pay($chat_id,'5000',$from_id)]],
[['text'=>"💰 10,000 تومان",'url'=>pay($chat_id,'10000',$from_id)],['text'=>"💰 20,000 تومان",'url'=>pay($chat_id,'20000',$from_id)]],
]
])
]);
}
//-------------------------------------------//
elseif ($text == '☎️ خرید شماره مجازی'){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"💠 سرویس مورد نظر را انتخاب کنید :",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"💎 تلگرام"],['text'=>"📺 اینستاگرام"],['text'=>"🔍 گوگل"]],
[['text'=>"📞 واتساپ"],['text'=>"📟 لاین"],['text'=>"🐝 بیتالک"]],
[['text'=>"☂️ وایبر"],['text'=>"🐣 توییتر"],['text'=>"🛄 فیسبوک"]],
[['text'=>"↪️ بازگشت"]],
],
'resize_keyboard'=>true,
])
]);
}
//-------------------------------------------//
elseif ($text == '💎 تلگرام' or $text == '📺 اینستاگرام' or $text == '📞 واتساپ' or $text == '🔍 گوگل' or $text == '📟 لاین' or $text == '🐝 بیتالک' or $text == '☂️ وایبر' or $text == '🛄 فیسبوک' or $text == '🐣 توییتر'){
    $az = array("💎 تلگرام","🔍 گوگل","📞 واتساپ","📺 اینستاگرام","📟 لاین","🐝 بیتالک","☂️ وایبر","🐣 توییتر","🛄 فیسبوک");
    $be = array("telegram","google","whatsapp","instagram","line","beetalk","viber","twitter","facebook");
    $text = str_replace($az,$be,$text);
    file_put_contents("data/$chat_id/app.txt","$text"); 

bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"☢️ کشور را انتخاب کنید :

⭐️ : شماره هایی که هنگام نصب ریپورت نیستند .
",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"$coun_malesia"],['text'=>"$coun_mesr"],['text'=>"$coun_ustra"]],
[['text'=>"$coun_africa"],['text'=>"$coun_engel"]],
[['text'=>"$coun_qhazaqh"],['text'=>"$coun_ocrain"],['text'=>"$coun_kamboji"]],
[['text'=>"$coun_chin"],['text'=>"$coun_tiland"],['text'=>"$coun_rus"]],
[['text'=>"$coun_vietnam"],['text'=>"$coun_andinesi"],['text'=>"$coun_macaoo"]],
[['text'=>"$coun_macaoo"],['text'=>"$coun_america"],['text'=>"$coun_hongkong"]],
[['text'=>"$coun_mianmar"],['text'=>"$coun_laus"],['text'=>"$coun_kenia"]],
[['text'=>"$coun_spain"],['text'=>"$coun_danmark"]],
[['text'=>"↪️ بازگشت"]],
],
'resize_keyboard'=>true,
])
]);
}
//-------------------------------------------//
elseif ($text == "$coun_danmark" or $text == "$coun_spain" or $text == "$coun_laus" or $text == "$coun_kenia" or $text == "$coun_qhazaqh" or $text == "$coun_engel" or $text == "$coun_ocrain" or $text  == "$coun_africa" or $text == "$coun_chin" or $text == "$coun_malesia" or $text == "$coun_tiland" or $text == "$coun_rus" or $text == "$coun_mesr" or $text == "$coun_mianmar" or $text == "$coun_kamboji"or $text == "$coun_vietnam" or $text == "$coun_andinesi" or $text == "$coun_macaoo" or $text == "$coun_macaoo" or $text == "$coun_ustra" or  $text == "$coun_america" or $text == "$coun_hongkong"){
    $country_az = array("$coun_danmark","$coun_spain","$coun_laus","$coun_kenia","$coun_africa","$coun_andinesi","$coun_malesia","$coun_mianmar","$coun_vietnam","$coun_kamboji","$coun_macaoo","$coun_tiland","$coun_hongkong","$coun_macaoo","$coun_rus","$coun_mesr","$coun_ustra","$coun_qhazaqh","$coun_ocrain","$coun_engel","$coun_chin","$coun_america");
    $country_be = array("DK","ES","la","ke","za","id","my","mm","vn","kh","ph","th","hk","mo","RU","eg","au","KZ","UA","UK","ch","am");
    $country = str_replace($country_az,$country_be,$text);
    file_put_contents("data/$chat_id/country.txt","$country");

    $price_az = array("DK","ES","RU","KZ","UA","UK","za","id","my","mm","vn","kh","ph","th","hk","mo","ru","eg","au","ke","la","ch","am");
    $price_be = array("3000","3000","1000","3000","3000","3000","4000","5000","7000","7000","4000","3000","5000","4000","3000","3000","4000","4000","6000","3000","3000","2000","4000");
    $upays = str_replace($price_az,$price_be,$country);
    file_put_contents("data/$chat_id/upay.txt","$upays");

if ($coin >= $upays){
    $getnumber = json_decode(file_get_contents("https://unumber.ir/bot/api/index.php?ApiKey=$ApiKey&action=GetNumber&country=$country&app=$app"),true);
   if($getnumber['Result'] == 'OK'){
    file_put_contents("data/$chat_id/number.txt",$getnumber['NumberID']); 
    file_put_contents("data/$chat_id/ShCH.txt",$getnumber['Number']); 

bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
☑️ شماره شما ساخته شد...
Number : +".$getnumber['Number']."

⚠️ شماره را در اپ مورد نظر وارد کرده و سپس روی گزینه [دریافت کد] کلیک کنید.
",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"🌐 دریافت کد"]],
[['text'=>"↪️ بازگشت"]],
],
'resize_keyboard'=>true,
])
]);
    }else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
⛔️ ربات در حال حاظر قادر به ارسال شماره برای این کشور نیست...

⚠️ لطفا چند دقیقه دیگر تلاش کنید و یا از شماره کشورهای دیگر استفاده کنید ...
",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"↪️ بازگشت"]],
],
'resize_keyboard'=>true,
])
]);
}

}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
⚠️ موجودی شما کافی نیست . . .

💰موجودی شما : $coin
🔰 هزینه این شماره : $upays
",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"💰 شارژ حساب"]],
[['text'=>"↪️ بازگشت"]],
],
'resize_keyboard'=>true,
])
]);
}

}
//-------------------------------------------//
elseif ($text == '🌐 دریافت کد'){
    $getnumber = json_decode(file_get_contents("http://unumber.ir/bot/api/index.php?ApiKey=$ApiKey&action=GetSms&country=$count&app=$app&NumberID=$number"),true);
    if($getnumber['Massage'] == "no received"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
⚠️ کد هنوز نیامده است . لطفا ابتدا شماره را در اپ مورد نظر وارد کرده و سپس روی دریافت کد کلیک کنید ...

✅ تا زمانی که کد را نگرفته اید از حساب شما  مبلغی کثر نخواهد شد.
",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"🌐 دریافت کد"]],
[['text'=>"↪️ بازگشت"]],
],
'resize_keyboard'=>true,
])
]);
}
    elseif($getnumber['Massage'] == "time out"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
📛 زمان استفاده از این شماره تموم شده.
💠 لطفا شماره دیگری مجدد دریافت کنید ...
",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"↪️ بازگشت"]],
],
'resize_keyboard'=>true,
])
]);
}
    elseif($getnumber['Result'] == "OK"){
        $coin -= $upay;
        file_put_contents("data/$chat_id/coin.txt","$coin"); 
        $ubuy += 1;
        file_put_contents("data/$chat_id/ubuy.txt","$ubuy"); 
        $AllBuy += $upay;
        file_put_contents("data/$chat_id/AllBuy.txt","$AllBuy"); 
        $AllBuyT += 1;
        file_put_contents("data/$chat_id/AllBuyT.txt","$AllBuyT"); 

    $strlen = strlen($ShCH)/2-2;
    $ShCH = str_replace(substr("$ShCH",$strlen,$strlen),"***",$ShCH);
    $country_az = array("DK","ES","la","ke","za","id","my","mm","vn","kh","ph","th","hk","mo","RU","eg","au","KZ","UA","UK","ch","am");
    $country_be = array("$coun_danmark","$coun_spain","$coun_laus","$coun_kenia","$coun_africa","$coun_andinesi","$coun_malesia","$coun_mianmar","$coun_vietnam","$coun_kamboji","$coun_macaoo","$coun_tiland","$coun_hongkong","$coun_macaoo","$coun_rus","$coun_mesr","$coun_ustra","$coun_qhazaqh","$coun_ocrain","$coun_engel","$coun_chin","$coun_america");
    $count = str_replace($country_az,$country_be,$count);
bot('sendMessage',[
'chat_id'=>$channel,
'text'=>"
📱یک عدد شماره مجازی $count خریداری شد!
⚜️اطلاعات شماره و خریدار 👇
➖➖➖➖➖➖➖➖
number : +$ShCH
➖➖➖➖➖➖➖➖
user : $chat_id
➖➖➖➖➖➖➖➖
❗️روش خرید و دریافت شماره مجازی :
۱-وارد ربات @UnumberBot شوید.
۲-اعتبار خود را $upay تومان افزایش دهید.
۳-شماره مجازی روسیه دریافت کنید!
☝️شماره های مجازی ثبت نشده هستند و با متد های اتومات توسط کاربران ربات @UnumberBot به صورت کاملا خودکار دریافت و ثبت می شوند.
این پیام  خودکار با دریافت کد شماره مجازی توسط کاربر ربات یو نامبر ارسال شده است.
***************
🤖 @UnumberBot
 🔊@Unumber

",
]);

bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
✅ کد دریافت شد :
 Code : ".$getnumber['Massage']."
",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'keyboard'=>[
[['text'=>"↪️ بازگشت"]],
],
'resize_keyboard'=>true,
])
]);
}
}
}
//-------------------------------------------//
if ($text == '/stats' and $chat_id == $admin){
    sendMessage($chat_id,"📍 تعداد کل کاربران : ".count($memlist)."\n☎️ تعداد کل فروش : $AllBuyT\n💵 هزینه های استفاده شده کاربران : $AllBuy","HTML");
}
//-------------------------------------------//
if(file_exists("error_log"))unlink("error_log");
?>